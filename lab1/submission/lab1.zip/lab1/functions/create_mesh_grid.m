function grid = create_mesh_grid(X1, X2)
    grid = zeros(height(X1), width(X2));
end