# SYDE572
Pattern Recognition: Winter 2021

Data for Lab 2 can be found in `lab_2_data/`
